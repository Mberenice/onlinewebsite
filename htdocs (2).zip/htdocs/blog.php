c<?php

$blogFile = 'blog.txt';

if (file_exists($blogFile)) {
    $blogPosts = file($blogFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);

    $blogPosts = array_reverse($blogPosts);

    echo '<!DOCTYPE html><html><head><meta charset="UTF-8"><title>Blog</title>';
    echo '<style>table { width: 100%; border-collapse: collapse; } th, td { border: 1px solid black; padding: 8px; } th { background-color: #f2f2f2; }</style>';
    echo '</head><body>';

    echo '<table>';
    Content</th></tr>'; 

foreach ($blogPosts as $post) {
        $post = htmlspecialchars($post); // Sanitize the post content
        list($name, $title, $imageFilename, $content, $date) = explode(',', $post, 5); 

echo "<tr>";
        echo "<td>{$title}</td>";
 echo "</tr>";
 echo "<tr>";
        echo "<td> by {$name}</td> on <td>{$date}</td>";
 echo "</tr>";
 echo "<tr>";
        echo "<td>";
        if ($imageFilename && file_exists("images/blog/{$imageFilename}")) {
            echo "<img src='images/blog/{$imageFilename}' alt=''>";
        }
        echo "</td>";
 echo "</tr>";
 echo "<tr>";
        echo "<td>{$content}</td>";
        echo "</tr>";
    }

echo '</table>';
    echo '</body></html>';
} else {
    echo "No blog posts found.";
}
?>