-- 
--1.	Drop all tables in the correct order.
DROP TABLE registration;
DROP TABLE orders1;
DROP TABLE product;
DROP TABLE customer;

--2.	Create all tables with no constraints
CREATE TABLE registration
(username 	varchar(16), 
 password 	varchar(16) 
);

CREATE TABLE product
(item_no     numeric(4),  
ebook_name   varchar(30), 
description  varchar(200),
image        varchar(30), 
price        numeric(9,2),
inventory    numeric 
);


CREATE TABLE orders1
(item_no     numeric(4),
 cc_no       numeric(16), 
 quantity    integer, 
 date_sold   date
 );

CREATE TABLE customer
(cc_no      numeric(16), 
exp_mo      numeric(2),  
exp_yr      numeric(4),  
name_first  varchar(20), 
name_last   varchar(20), 
email       varchar(20), 
address1    varchar(50), 
address2    varchar(50),  
city        varchar(20), 
state       varchar(2),  
zip         numeric(5),  
country     varchar(20),
phone       varchar(15), 
fax         varchar(15), 
mail_list   numeric(1)
);


--3. Create all primary key constraints
ALTER TABLE orders1 ADD CONSTRAINT pk_orders1 PRIMARY KEY (item_no, cc_no, date_sold);
ALTER TABLE customer ADD CONSTRAINT pk_customer PRIMARY KEY (cc_no);
ALTER TABLE product ADD CONSTRAINT pk_product PRIMARY KEY (item_no);
ALTER TABLE registration ADD CONSTRAINT pk_registration PRIMARY KEY (username);

--4. Create all foreign key constraints
ALTER TABLE orders1 ADD CONSTRAINT fk_orders1_item FOREIGN KEY (item_no) REFERENCES product(item_no);
ALTER TABLE orders1 ADD CONSTRAINT fk_orders1_cc FOREIGN KEY (cc_no) REFERENCES customer(cc_no);

--5. Create all not null constraints
ALTER TABLE registration MODIFY password VARCHAR(16) NOT NULL;
ALTER TABLE product MODIFY item_no NUMERIC(4) NOT NULL,
    MODIFY ebook_name VARCHAR(30) NOT NULL,
    MODIFY description VARCHAR(200) NOT NULL,
    MODIFY image VARCHAR(30) NOT NULL,
    MODIFY price NUMERIC(9,2) NOT NULL,
    MODIFY inventory NUMERIC NOT NULL;
ALTER TABLE orders1 MODIFY item_no NUMERIC(4) NOT NULL,
    MODIFY cc_no NUMERIC(16) NOT NULL,
    MODIFY quantity INTEGER NOT NULL,
    MODIFY date_sold DATE NOT NULL;
ALTER TABLE customer MODIFY cc_no NUMERIC(16) NOT NULL,
    MODIFY exp_mo NUMERIC(2) NOT NULL,
    MODIFY exp_yr NUMERIC(4) NOT NULL,
    MODIFY name_first VARCHAR(20) NOT NULL,
    MODIFY name_last VARCHAR(20) NOT NULL,
    MODIFY email VARCHAR(20) NOT NULL,
    MODIFY address1 VARCHAR(50) NOT NULL,
    MODIFY city VARCHAR(20) NOT NULL,
    MODIFY state VARCHAR(2) NOT NULL,
    MODIFY zip NUMERIC(5) NOT NULL,
    MODIFY phone VARCHAR(15) NOT NULL,
    MODIFY fax VARCHAR(15) NOT NULL;


--6. Insert all initial rows in product table for all 8 products
INSERT INTO product (item_no, ebook_name, description, image, price, inventory) 
VALUES 
(1, 'The Exercise Cure', 'A Doctor''s All Natural Solution to Better Health and a Longer Life.', 'NoExercise.jpg', 1.99, 5),
(2, 'Daniel Plan', 'The Tried and Tested Dietary Plan to Change Your Life.', 'HealthPlan.jpg', 2.99, 5),
(3, 'Soul Healing', 'A Guide to a Happy and Healthy Life by Basic Lifestyle Changes.', 'Soul.jpg', 1.99, 5),
(4, 'Wheat Belly', 'Wheat - The Real Wonder Food for the 21st Century.', 'WheatBelly.jpg', 0.99, 5),
(5, 'What To Expect', 'A Health and Exercise Guide for Expecting Mothers', 'expect.jpg', 3.99, 5),
(6, 'The First Year', 'A Health and Exercise Guide for Mothers in their First Year.', 'expect1.jpg', 1.99, 5),
(7, 'Hands Free Mama', 'Become a Multi-Tasking Mama with Less Stress', 'Mama.jpg', 0.99, 5),
(8, 'Talk to Kids', 'A Guide to Communicating with Your Children', 'talk.jpg', 2.99, 5);
