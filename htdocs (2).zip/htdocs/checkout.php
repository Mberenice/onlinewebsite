<?php
session_start(); // Start the PHP session to maintain data across different pages
include 'config.php'; // Include your database configuration file if needed
// Function to calculate the total price of the cart
function calculateTotal($cart) {
    $total = 0;
    foreach ($cart as $item) {
        $total += $item['quantity'] * $item['price'];
    }
    return $total;
}

?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8" />
    <title>Shopping Cart Review</title>
    <script src="JavaScript.js"></script>
</head>
<body onload="updateCartTable()" style="background-color: grey;">

    <center>
        <h1>Enter Customer Info Below</h1>
    </center>

    <form action="processCheckout.php" method="post">
        <table align="center">
            <tr>
                <td>First Name:</td>
                <td>
                    <input type="text" name="firstName" pattern="[A-Za-z ]+" required title="This field is required" />
                </td>
            </tr>
            <tr>
                <td>Last Name:</td>
                <td>
                    <input type="text" name="lastName" pattern="[A-Za-z ]+" required title="This field is required" />
                </td>
            </tr>
            <tr>
                <td>Email:</td>
                <td>
                    <input type="email" name="email" required />
                </td>
            </tr>
            <tr>
                <td>Address 1:</td>
                <td>
                    <input type="text" name="address1" required title="Address 1 is required." />
                </td>
            </tr>
            <tr>
                <td>Address 2:</td>
                <td>
                    <input type="text" name="address2" />
                </td>
            </tr>
            <tr>
                <td>City:</td>
                <td>
                    <input type="text" name="city" pattern="[A-Za-z ]+" required title="City can only contain letters and space." />
                </td>
            </tr>
            <tr>
                <td>State:</td>
                <td>
                    <input type="text" name="state" pattern="[A-Z]{2}" required title="Must be 2 capital letters." />
                </td>
            </tr>
            <tr>
                <td>ZIP:</td>
                <td>
                    <input type="text" name="zip" pattern="\d{5}" required title="ZIP code must be 5 digits." />
                </td>
            </tr>
            <tr>
                <td>Country:</td>
                <td>
                    <input type="text" name="country" required />
                </td>
            </tr>
            <tr>
                <td>Phone:</td>
                <td>
                    <input type="tel" name="phone" pattern="(\d{3})?\d{3}-?\d{4}|\d{10}" required title="Valid formats: 5555555555, (555)555-5555, 555-555-5555." />
                </td>
            </tr>
            <tr>
                <td>Fax:</td>
                <td>
                    <input type="tel" name="fax" pattern="(\d{3})?\d{3}-?\d{4}|\d{10}" title="Valid formats: 5555555555, (555)555-5555, 555-555-5555." />
                </td>
            </tr>
            <tr>
                <td colspan="2">
                    <input type="checkbox" name="mailingList" />
                    Check here to be added to the mailing list
                </td>
            </tr>
        </table>


           <h2>Shopping Cart Review</h2>
<table>
    <tr>
        <th>Product</th>
        <th>Quantity</th>
        <th>Price</th>
        <th>Total Price</th>
    </tr>
    <?php
    if (isset($_SESSION['cart']) && !empty($_SESSION['cart'])) {
        foreach ($_SESSION['cart'] as $id => $item) {
            $lineCost = $item['quantity'] * $item['price'];
            echo "<tr>";
            echo "<td><img src='/NoExercise.jpg' alt='Product Image' style='width: 50px; height: auto;'><br>" .
                 htmlspecialchars($item['name']) . "</td>";
            echo "<td>" . htmlspecialchars($item['quantity']) . "</td>";
            echo "<td>$" . htmlspecialchars(number_format($item['price'], 2)) . "</td>";
            echo "<td>$" . htmlspecialchars(number_format($lineCost, 2)) . "</td>";
            echo "</tr>";
        }
        $totalCost = calculateTotal($_SESSION['cart']);
        echo "<tr><td colspan='3' style='text-align: right;'>Total:</td>";
        echo "<td>$" . htmlspecialchars(number_format($totalCost, 2)) . "</td></tr>";
    } else {
        echo "<tr><td colspan='4'>Your cart is empty.</td></tr>";
    }
    ?>
</table>
        </table>


        <center>
            <h2>Enter Credit Card Information Below</h2>
        </center>
        <table align="center">
            <tr>
                <td>Credit Card Type:</td>
                <td>
                    <input type="radio" name="cc_type" value="MasterCard" required />
                     <img src="mc.jpg" alt="visa" width="30" height="30" />
                    <input type="radio" name="cc_type" value="Visa" required />
                     <img src="visa.jpg" alt="visa" width="30" height="30" />
                    <input type="radio" name="cc_type" value="American Express" required />
                      <img src="mc.jpg" alt="American" width="30" height="30" />
                    <input type="radio" name="cc_type" value="Discover" required />
                      <img src="discover.jpg" alt="American" width="30" height="30" />
                </td>
            </tr>
            <tr>
                <td>Credit Card Number:</td>
                <td>
                    <input type="text" name="card_number" pattern="\d{16}" required title="This should be 16 digits." />
                </td>
            </tr>
            <tr>
                <td>Expiration Date:</td>
                <td>
                    <select name="exp_month" required>
                        <option value="1">January</option>
                        <option value="2">February</option>
                        <!-- Additional months here -->
                    </select>
                    <select name="exp_year" required>
                        <option value="2021">2021</option>
                        <option value="2022">2022</option>
                        <!-- Additional years here -->
                    </select>
                </td>
            </tr>
        </table>
        <div style="text-align: center;">
            <button type="submit">Buy Now</button>
            <button type="reset">Reset</button>
        </div>
    </form>

</body>
</html>
