<?php
session_start(); // Start the session

include 'config.php'; // Include your database connection

$productID = isset($_GET['id_no']) ? (int) $_GET['id_no'] : 0;

if ($productID > 0) {
    $stmt = $pdo->prepare("SELECT * FROM product WHERE item_no = :item_no");
    $stmt->bindParam(":item_no", $productID, PDO::PARAM_INT);
    $stmt->execute();
    $product = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($product) {
        echo "<!DOCTYPE html>";
        echo "<html lang='en'>";
        echo "<head>";
        echo "<meta charset='UTF-8'>";
        echo "<title>" . htmlspecialchars($product['ebook_name']) . "</title>";
        echo "</head>";
        echo "<body>";

        echo "<h1>" . htmlspecialchars($product['ebook_name']) . "</h1>";
        echo "<img src='/" . htmlspecialchars($product['image']) . "' alt='Product Image' />";
        echo "<p>" . nl2br(htmlspecialchars($product['description'])) . "</p>";
        echo "<p>Price: $" . htmlspecialchars($product['price']) . "</p>";

        // Check inventory and display the Buy Now or Sold Out message
        if ($product['inventory'] > 0) {
            // Direct the form action to `checkout.php` instead of `processCheckout.php`
            echo "<form action='checkout.php' method='post'>";
            echo "<input type='hidden' name='item_no' value='" . htmlspecialchars($product['item_no']) . "' />";
            echo "<input type='hidden' name='product_name' value='" . htmlspecialchars($product['ebook_name']) . "' />";
            echo "<input type='hidden' name='price' value='" . htmlspecialchars($product['price']) . "' />";
            echo "<label for='quantity'>Quantity:</label>";
            echo "<input type='number' id='quantity' name='quantity' value='1' min='1' max='" . htmlspecialchars($product['inventory']) . "' required>";
            echo "<button type='submit'>Buy Now</button>";
            echo "</form>";
            // Include JavaScript to handle quantity changes and validate against inventory
            echo "<script>
            var inventory = " . json_encode($product['inventory']) . ";
            document.getElementById('quantity').addEventListener('change', function() {
                if (this.value > inventory) {
                    alert('Only ' + inventory + ' items in stock.');
                    this.value = inventory; // Reset the value to the max inventory count
                }
            });
          </script>";
        } else {
            echo "<p>Sold Out</p>";
        }

        echo "</body>";
        echo "</html>";
    } else {
        echo "Product not found.";
    }
} else {
    echo "Invalid product ID.";
}

// Close the database connection
unset($stmt);
unset($pdo);
?>
