﻿function reviewCart() {
    var cart = JSON.parse(localStorage.getItem('cart')) || [];
    if (cart.length === 0) {
        alert("Empty cart - please buy something first");
    } else {
        window.location.href = "cart_page.html";
    }
}

function addToCart(id, itemName, price, imgSrc, quantity) {
    var userResponse = confirm(`Add ${itemName} to cart?`);
    if (userResponse) {
        var quantity = parseInt(document.getElementById("quantity").value) || 1;
        var cart = JSON.parse(localStorage.getItem('cart')) || [];
        var itemIndex = cart.findIndex(item => item.id === id);
        if (itemIndex > -1) {
           cart.push({ id: id, name: itemName, quantity: quantity, price: price, imgSrc: imgSrc });


        } else {
            cart.push({ id: id, name: itemName, quantity: quantity, price: price, imgSrc: imgSrc });
        }
        localStorage.setItem('cart', JSON.stringify(cart));
        alert("Successfully added to cart.");
        window.location.href = "store_index.html";
    } else {
        alert("Nothing added to cart.");
    }
}

function updateCartTable() {
    var cart = JSON.parse(localStorage.getItem('cart')) || [];
    var table = document.getElementById("cartTable"); // Ensure the ID matches your HTML

    // Clear the table except for the header
    while (table.rows.length > 1) {
        table.deleteRow(1);
    }

    // Calculate the total cost
    var total = 0;
    cart.forEach(function (item, index) {
        var row = table.insertRow();

        // Catalog number
        row.insertCell(0).innerText = index + 1;

        // Item description cell
        var cellItem = row.insertCell(1);
        cellItem.innerHTML = `
            <div class="item-container">
                <div>${item.name}</div>
                <img src="${item.imgSrc}" alt="${item.name}" class="cart-item-image">
                <button class="remove-button" onclick="removeFromCart('${item.id}')">Remove</button>
            </div>
        `;


        // Price
        row.insertCell(2).innerText = `$${item.price.toFixed(2)}`;

        // Quantity
        row.insertCell(3).innerText = item.quantity;

        // Total price for this item
        row.insertCell(4).innerText = `$${(item.price * item.quantity).toFixed(2)}`;

        // Update the total
        total += item.price * item.quantity;
    });

    // Add the grand total row
    var footerRow = table.insertRow();
    var footerCell = footerRow.insertCell(0);
    footerCell.colSpan = 4;
    footerCell.style.textAlign = "right";
    footerCell.innerHTML = "<b>Total</b>";

    var footerCellTotal = footerRow.insertCell(1);
    footerCellTotal.innerText = `$${total.toFixed(2)}`;
    footerCellTotal.colSpan = 2;



}

function removeFromCart(id)
{

    var cart = JSON.parse(localStorage.getItem('cart')) || [];
    var newCart = cart.filter(item => item.id !== id);
    localStorage.setItem('cart', JSON.stringify(newCart));
    alert("Are you sure you wanna remove the item ");
    updateCartTable();


    if (newCart.length === 0) {
        alert("Empty cart - please buy something first");
    } else {
        window.location.href = "store_index.html";
    }

    
}