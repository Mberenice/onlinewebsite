<?php
session_start();
include 'config.php';  // Include your configuration file with the database connection

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Collect customer information from form
    $firstName = filter_var($_POST['firstName'], FILTER_SANITIZE_STRING);
    $lastName = filter_var($_POST['lastName'], FILTER_SANITIZE_STRING);
    $email = filter_var($_POST['email'], FILTER_SANITIZE_EMAIL);
    $address1 = filter_var($_POST['address1'], FILTER_SANITIZE_STRING);
    $address2 = filter_var($_POST['address2'], FILTER_SANITIZE_STRING);
    $city = filter_var($_POST['city'], FILTER_SANITIZE_STRING);
    $state = filter_var($_POST['state'], FILTER_SANITIZE_STRING);
    $zip = filter_var($_POST['zip'], FILTER_SANITIZE_STRING);
    $country = filter_var($_POST['country'], FILTER_SANITIZE_STRING);
    $phone = filter_var($_POST['phone'], FILTER_SANITIZE_STRING);
    $fax = filter_var($_POST['fax'], FILTER_SANITIZE_STRING);
    $mailingList = isset($_POST['mailingList']) ? 1 : 0;
    $cardType = filter_var($_POST['cc_type'], FILTER_SANITIZE_STRING);
    $cardNumber = filter_var($_POST['card_number'], FILTER_SANITIZE_STRING);
    $expMonth = filter_var($_POST['exp_month'], FILTER_SANITIZE_NUMBER_INT);
    $expYear = filter_var($_POST['exp_year'], FILTER_SANITIZE_NUMBER_INT);

    try {
        // Start transaction
        $pdo->beginTransaction();

        // Insert customer data
        $customerSql = "INSERT INTO customers (firstName, lastName, email, address1, address2, city, state, zip, country, phone, fax, mailingList, cc_type, card_number, exp_month, exp_year)
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        $stmt = $pdo->prepare($customerSql);
        $stmt->execute([$firstName, $lastName, $email, $address1, $address2, $city, $state, $zip, $country, $phone, $fax, $mailingList, $cardType, $cardNumber, $expMonth, $expYear]);
        $customerId = $pdo->lastInsertId();

        // Insert orders for each product in cart
        foreach ($_SESSION['cart'] as $id => $item) {
            $orderSql = "INSERT INTO orders (customerId, productId, quantity, price, date) VALUES (?, ?, ?, ?, NOW())";
            $stmt = $pdo->prepare($orderSql);
            $stmt->execute([$customerId, $id, $item['quantity'], $item['price']]);

            // Update inventory
            $updateInventorySql = "UPDATE product SET inventory = inventory - ? WHERE item_no = ?";
            $stmt = $pdo->prepare($updateInventorySql);
            $stmt->execute([$item['quantity'], $id]);
        }

        // Commit transaction
        $pdo->commit();

        echo "Order placed successfully and customer data saved!";
    } catch (PDOException $e) {
        $pdo->rollBack();
        die("ERROR: Could not complete the transaction - " . $e->getMessage());
    }

    // Clear the cart after processing
    unset($_SESSION['cart']);
} else {
    echo "No data received.";
}

?>
