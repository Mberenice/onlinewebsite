<?php
session_start();
include 'config.php'; // Make sure this points to your actual config file

// Fetch parenting products from the database
try {
    $stmt = $pdo->query("SELECT id, name, image_path FROM products WHERE category='Parenting'");
    $products = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die("Error connecting to the database: " . $e->getMessage());
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Parenting E-Book Collection</title>
    <style>
        body {
            text-align: center;
            font-family: Arial, sans-serif;
        }
        .grid-container {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 20px;
            margin-top: 20px;
        }
        .grid-item {
            border: 1px solid #ccc;
            padding: 10px;
        }
        .grid-item img {
            max-width: 100%;
            height: auto;
        }
        .continue-shopping {
            margin-top: 20px;
        }
    </style>
</head>
<body>

    <h1>Parenting E-Book Collection</h1>
    <h2>Select One Today!</h2>

    <div class="grid-container">
        <?php foreach ($products as $product): ?>
            <div class="grid-item">
                <a href="processProduct.php?id_no=<?php echo $product['id']; ?>">
                    <img src="<?php echo htmlspecialchars($product['image_path']); ?>" alt="<?php echo htmlspecialchars($product['name']); ?>">
                    <p><?php echo htmlspecialchars($product['name']); ?></p>
                </a>
            </div>
        <?php endforeach; ?>
    </div>

    <div class="continue-shopping">
        <a href="index.php">Continue Shopping</a>
    </div>

</body>
</html>
