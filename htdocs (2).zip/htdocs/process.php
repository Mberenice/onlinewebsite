<?php

// Define constants for the uploads and text file.
define('UPLOAD_DIR', 'images/blog/');
define('BLOG_FILE', 'blog.txt');

// Function to generate a unique filename for the uploaded image
function generateFilename($originalName)
{
    $extension = pathinfo($originalName, PATHINFO_EXTENSION);
    $basename = bin2hex(random_bytes(8)); 
    return sprintf('%s.%0.8s', $basename, $extension);
}

//
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['name'];
    $title = $_POST['title'];
    $blogContent = $_POST['blog-content'];
    $currentDate = date('d-m-y');

    $imageFilename = '';
    if (isset($_FILES['image']) && $_FILES['image']['error'] == UPLOAD_ERR_OK) {

        $imageFilename = generateFilename($_FILES['image']['name']);
         if (!move_uploaded_file($_FILES['image']['tmp_name'], UPLOAD_DIR . $imageFilename)) {
            // Handle error if the file can't be moved
            die("Error uploading image.");
        }
    }

    // blog entry and append to the file
    $blogEntry = "{$name},{$title},{$imageFilename},{$blogContent},{$currentDate}\n";
    file_put_contents(BLOG_FILE, $blogEntry, FILE_APPEND | LOCK_EX);

    // Redirect to a confirmation page or back to the form
    header('Location: admin.html');
    exit;
}


else {
    echo "Please submit the form.";
}
?>